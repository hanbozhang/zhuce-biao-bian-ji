﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 注册表编辑器
{
    class Clauses
    {
        /// <summary>
        /// 根项
        /// </summary>
        public string RegKey { get; set; }
        /// <summary>
        /// 删除或添加
        /// </summary>
        public bool Del_Or_Ins { get; set; }
        /// <summary>
        /// 路径
        /// </summary>
        public string RegPath { get; set; }
        /// <summary>
        /// 键值类型
        /// </summary>
        public string KeyValuesClass { get; set; }
        /// <summary>
        /// 键名称
        /// </summary>
        public string Key_Name { get; set; }
        /// <summary>
        /// 值
        /// </summary>
        public string Value { get; set; }
    }
}
