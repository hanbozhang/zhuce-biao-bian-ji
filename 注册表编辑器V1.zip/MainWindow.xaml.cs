﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Win32;
using System.Xml.Linq;
using System.Xml;
using System.IO;
using System.ComponentModel;
using System.Data;

namespace 注册表编辑器
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        #region 预加载列表与字典
        /// <summary>
        /// 根项列表
        /// </summary>
        Dictionary<string, RegistryKey> regkeyValueDic = new Dictionary<string, RegistryKey>
        {
            { "HKEY_CLASSES_ROOT",Registry.ClassesRoot },
            {"HKEY_CURRENT_USER",Registry.CurrentUser },
            {"HKEY_LOCAL_MACHINE",Registry.LocalMachine },
            {"HKEY_USERS",Registry.Users },
            {"HKEY_CURRENT_CONFIG",Registry.CurrentConfig }
        };

        /// <summary>
        /// 值类型列表
        /// </summary>
        Dictionary<string, string> Key_Class_Dic = new Dictionary<string, string>();
        /// <summary>
        /// 预设字典
        /// </summary>
        Dictionary<string, Function> Func_Dic = new Dictionary<string, Function>();
        /// <summary>
        /// 加载值类
        /// </summary>
        public void LoadKeyClass()
        {
            if (!File.Exists("KeyClass.xml"))
                this.Close();

            IEnumerable<XElement> Keys = XDocument.Load("KeyClass.xml").Element("keyClass").Elements("key");
            foreach (var key in Keys)
                Key_Class_Dic.Add(key.Attribute("Value").Value, key.Attribute("Name").Value);
        }
        /// <summary>
        /// 加载预设
        /// </summary>
        public void LoadFunctions()
        {
            Func_Dic.Clear();
            if (!File.Exists("Implement.xml"))
                return;
            IEnumerable<XElement> Funcs = XDocument.Load("Implement.xml").Element("Imple").Elements("Implement");
            foreach (var Fun in Funcs)
            {

                Function function = new Function()
                {
                    Function_Name = Fun.FirstAttribute.Value
                };
                function.Clausess = new List<Clauses>();
                foreach (var Clsues in Fun.Elements("Clsuses"))
                {
                    Clauses clauses = new Clauses()
                    {
                        Key_Name = Clsues.Attribute("KeyName").Value,
                        KeyValuesClass = Clsues.Attribute("KeyValuesClass").Value,
                        Value = Clsues.Value,
                        RegKey = Clsues.Attribute("RegKey").Value,
                        RegPath = Clsues.Attribute("RegPath").Value,
                        Del_Or_Ins = Clsues.Attribute("DelOrIns").Value == "true" ? true : false
                    };
                    function.Clausess.Add(clauses);
                }
                Func_Dic.Add(Fun.FirstAttribute.Value, function);
            }
            Func_Dic.Add("", new Function());
            Fun_Cmb.ItemsSource = null;
            Fun_Cmb.ItemsSource = Func_Dic.Keys;
            Fun_Cmb.SelectedIndex = Func_Dic.Keys.Count - 1;
        }
        /// <summary>
        /// 暂存过程列表
        /// </summary>
        Function function;
        #endregion

        #region 加载程序
        public MainWindow()
        {
            InitializeComponent();
            LoadKeyClass();
            LoadFunctions();
            RegKey_Cmb.ItemsSource = regkeyValueDic.Keys;
            RegKey_Cmb.SelectedIndex = 0;
            KeyClass_Cmb.ItemsSource = Key_Class_Dic.Keys;
            KeyClass_Cmb.SelectedIndex = 0;
        }
        #endregion

        #region 窗体拖动事件
        /// <summary>
        /// 窗体拖动事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Window_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
                this.DragMove();
        }
        #endregion

        #region 窗口最小化与关闭事件
        private void Min_btn_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void Close_btn_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        #endregion

        #region 添加列表
        private void InsBtn_Click(object sender, RoutedEventArgs e)
        {
            if (RegPath_TB.Text == "")
                return;
            if (function == null)
                function = new Function();
            if (function == new Function())
                function.Function_Name = FunName_TB.Text;
            if (function.Clausess == null)
                function.Clausess = new List<Clauses>();
            Clauses clauses = new Clauses();
            clauses.Key_Name = KeyName_TB.Text == "(默认)" ? "" : KeyName_TB.Text;
            clauses.KeyValuesClass = Key_Class_Dic[KeyClass_Cmb.SelectedValue.ToString()];
            clauses.Value = Ins_Rad.IsChecked == true ? Value_TB.Text : "";
            clauses.RegKey = RegKey_Cmb.SelectedValue.ToString();
            clauses.RegPath = RegPath_TB.Text;
            clauses.Del_Or_Ins = Ins_Rad.IsChecked == true ? true : false;
            function.Clausess.Add(clauses);
            DGrid.DataContext = null;
            DGrid.DataContext = function.Clausess;
        }
        #endregion

        #region 预设选择改变事件
        /// <summary>
        /// 预设选择改变事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Fun_Cmb_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (Fun_Cmb.SelectedValue==null|| Fun_Cmb.SelectedValue.ToString() == "")
            {
                function = new Function();
                FunName_TB.Text = "";
                DGrid.DataContext = null;
                return;
            }
            DGrid.DataContext = null;
            function = new Function();
            function = Func_Dic[Fun_Cmb.SelectedValue.ToString()];
            FunName_TB.Text = function.Function_Name;

            DGrid.DataContext = function.Clausess;
        }
        #endregion

        #region 删除列表
        /// <summary>
        /// 删除列表
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void DelBtn_Click(object sender, RoutedEventArgs e)
        {
            if (DGrid.SelectedValue == null)
                return;
            function.Clausess.Remove((Clauses)DGrid.SelectedValue);
            DGrid.DataContext = null;
            DGrid.DataContext = function.Clausess;
        }
        #endregion

        #region 运行事件
        private void Exe_Btn_Click(object sender, RoutedEventArgs e)
        {
            #region 循环所有列表中的所有流程
            try
            {
                foreach (Clauses clauses in function.Clausess)
                {
                    RegistryKey registryKey = regkeyValueDic[clauses.RegKey].OpenSubKey(clauses.RegPath, true);
                    if (!clauses.Del_Or_Ins)
                    {
                        try
                        {
                            if (registryKey == null)
                                continue;
                            if (clauses.Key_Name != "")
                                registryKey.DeleteSubKeyTree(clauses.Key_Name);
                            if (clauses.Value != "")
                                foreach (string key in clauses.Value.Split('.', '|', '\\', '/'))
                                    registryKey.DeleteValue(key);
                            continue;
                        }
                        catch
                        {
                            MessageBox.Show("权限出错请修改权限或查看相关路径值是否出错");
                        }
                    }
                    if (registryKey == null)
                    {
                        registryKey = regkeyValueDic[RegKey_Cmb.SelectedValue.ToString()];
                        string[] PathZ = clauses.RegPath.Split('\\');
                        string Paths = "";
                        foreach (string Path in PathZ)
                        {
                            registryKey = regkeyValueDic[RegKey_Cmb.SelectedValue.ToString()];
                            Paths += $"{(Paths.Length != 0 ? @"\" : "")}{Path}";
                            registryKey.CreateSubKey(Paths);

                        }
                    }
                    registryKey.SetValue(clauses.Key_Name, clauses.Value, (RegistryValueKind)Enum.Parse(typeof(RegistryValueKind), clauses.KeyValuesClass));
                }
            }
            catch 
            {

                MessageBox.Show("权限出错请修改权限或查看相关路径值是否出错");
            }
            #endregion
            #region 如果写有预设名称则保存
            if (FunName_TB.Text == "")
                return;
            if (Func_Dic.Keys.Contains(FunName_TB.Text))
                return;
            function.Function_Name = FunName_TB.Text;
            XElement element = new XElement(new XElement("Implement", new XAttribute("Name", function.Function_Name)));
            foreach (Clauses clauses in function.Clausess)
            {
                XElement Clu = new XElement("Clsuses");
                Clu.Add(new XAttribute("RegKey", clauses.RegKey));
                Clu.Add(new XAttribute("RegPath", clauses.RegPath));
                Clu.Add(new XAttribute("KeyValuesClass", clauses.KeyValuesClass));
                Clu.Add(new XAttribute("KeyName", clauses.Key_Name));
                Clu.Add(new XAttribute("DelOrIns", clauses.Del_Or_Ins ? "true" : "false"));
                Clu.Add(clauses.Value);
                element.Add(Clu);
            }
            XDocument document = XDocument.Load("Implement.xml");
            XElement Imp = document.Element("Imple");
            Imp.Add(element);
            document.Save("Implement.xml");
            LoadFunctions();
            #endregion
        }
        #endregion

        #region 删除与修改模式页面的改变
        private void Del_Rad_Click(object sender, RoutedEventArgs e)
        {
            KeyClass_Cmb.IsEditable = true;
            NXTB.Text = "项：";
            KeyName_TB.Text = "";
            JZTB.Text = "键：";
        }

        private void Ins_Rad_Click(object sender, RoutedEventArgs e)
        {
            KeyClass_Cmb.IsEditable = false;
            NXTB.Text = "名称：";
            KeyName_TB.Text = "(默认)";
            JZTB.Text = "值：";
        }
        #endregion
    }
}
