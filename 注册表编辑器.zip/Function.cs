﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace 注册表编辑器
{
    class Function
    {
        public string Function_Name { get; set; }
        public List<Clauses> Clausess{ get; set; }
    }
}
